
document.getElementById("addList").addEventListener("submit",function(e){
e.preventDefault();    

var todo = document.createElement("ToDo").value;
todo.type = "input";
        
var checkbox = document.createElement("input");
checkbox.type = "checkbox";
        
var ul = document.createElement("ul");

var addlBtn = document.createElement("button");
addBtn.type="submit";
        
var delBtn = document.createElement("button");
delBtn.type="submit";
        
    
    checkbox.addEventListener("change", function() {
        if(checkbox.checked) {
            ul.style.textDecoration="line-through";
            } else {
            ul.style.textDecoration="none";
        }
    });
}

    ,form.addEventListener("submit", function() {
        form.remove();
    })
);




/*

// 追加ボタン
const addBtn = document.createElement("button");
addBtn.type = "submit";
addBtn.className = "addBtn";

function addToList() {
    const input = document.getElementsByClassName("ToDo");
    
}


// 削除ボタン
const delBtn = document.createElement("button");
delBtn.type = "submit";
delBtn.className = "delBtn";

function delToList() {

}


// 取り消し線
const checkbox = document.createElement("checkbox");
checkbox.type = "checkbox";
checkbox.className = "checkbox";

checkbox.addEventListener("change", function() {
    if(checkbox.checked) {
        ul.style.textDecoration = "line-through 1px black";
    } else {
        ul.style.textDecoration = "none";
    }
});

const ul = document.createElement("ul");
ul.className = "lists";
ul.textContent = text;

*/

/* 
    参考
    https://www.javadrive.jp/javascript/form/index2.html
    https://www.javadrive.jp/javascript/form/index1.html
    https://developer.mozilla.org/ja/docs/Learn_web_development/Core/Scripting/A_first_splash
    https://qiita.com/yjn279/items/0b0bd72330974186be8c
    https://developer.mozilla.org/ja/docs/Web/API/Document
    https://developer.mozilla.org/ja/docs/Learn_web_development/Getting_started/Your_first_website/Adding_interactivity


*/